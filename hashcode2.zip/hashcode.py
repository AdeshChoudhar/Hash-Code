with open("a.txt") as f:
        lines = f.readlines()

D, I, S, V, F = list(map(int, lines[0].split()))

graph_elements = dict()
street = dict()
path = dict(); counter = 0; indeg = []
for q in range(I):
    indeg.append(0)
for i in range(1, S + 1):
    B, E, street_name, L = lines[i].split()
    B, E, L = int(B), int(E), int(L)
    street[street_name] = [B,E]

    if E not in list(graph_elements.keys()):
        graph_elements[E] = []; indeg[E] +=1;
    graph_elements[E].append([B, street_name, L,0, [] ])

for i in range(S + 1, S + V + 1):
    input = lines[i].split()
    P, streets_required = input[0], input[1:]; P = int(P)
    path[counter] = [P, streets_required]
    counter +=1
   
print(street)
print(graph_elements)
print(path)
car = dict()
for j in range(counter):
    car[j]=[]
    for q in range(path[j][0]):
        car[j].append( street[path[j][1][q]][0] )
    car[j].append(street[path[j][1][q-1]][1] )
print(car)
dealtIntex = 0
schedule =dict()
for i in range(I):
    schedule[i]=[]
    for z in range(indeg[i]):
        schedule[i].append([graph_elements[i][0][1], str(1)])

print(schedule)
    
opfile = open("Schedule.txt","w"); s = "\n";
opfile.write(str(dealtIntex))
opfile.write(s)
for z in range(I):
    opfile.write(str(z))
    opfile.write(s)
    opfile.write(str(indeg[z]))
    opfile.write(s)
    opfile.write(schedule[i][0][0])
    opfile.write(" ")
    opfile.write(schedule[i][0][1])

opfile.close






